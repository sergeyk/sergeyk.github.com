// TODO:
// BY END OF FINALS WEEK: webpage detailing what's in the project and a link to it
// - link up to a pong or fishbowlvr-like demo
// - develop gesture recording and matching (dynamic gesture learning)
// - develop a more precise tracking method based on the search window
package camteraction;

import controlP5.*;
import processing.core.*;
import processing.video.Capture;
import java.awt.*;
import java.awt.event.*;
import java.util.LinkedList;

public class Main extends PApplet {

  // CONSTANTS
  public static final int CONTROL_WIDTH = 140;
  public static final int CAM_WIDTH = 480;
  public static final int CAM_HEIGHT = 360;
  public static final int CAM_FRAMERATE = 20;
  public final int BACKGROUND = color(180);
  // VARIABLES
  private boolean display_framerate = true;
  private boolean robot_on = false;
  private boolean range_calibration_on = false;
  private int screen_width,  screen_height;
  // OBJECTS
  private LinkedList<Point> tracker_history;
  private Capture cam;
  private DifferenceMoments moments_tracker;
  private SearchWindow search_window;
  private GestureRecognizer gesture_recognizer;
  private Robot robot;
  private ControlP5 controlP5;

  public static void main(String[] args) {
    PApplet.main(new String[]{"camteraction.Main"});
  }
  private Point tracker_max,  tracker_min;

  @Override
  public void setup() {
    size(CAM_WIDTH * 2 + CONTROL_WIDTH, CAM_HEIGHT * 2);
    colorMode(RGB);
    frameRate(CAM_FRAMERATE);
    smooth();
    background(BACKGROUND);
    try {
      cam = new Capture(this, CAM_WIDTH, CAM_HEIGHT, CAM_FRAMERATE);
      //cam.settings();
      moments_tracker = new DifferenceMoments(this, CAM_WIDTH, CAM_HEIGHT);
      gesture_recognizer = new GestureRecognizer(this);
      search_window = new SearchWindow(this);
      tracker_history = new LinkedList<Point>();
      tracker_max = new Point(CAM_WIDTH, CAM_HEIGHT);
      tracker_min = new Point(0, 0);
      controlP5 = new ControlP5(this);
      setupControls();
      try {
        robot = new Robot();
        Dimension screen_size = Toolkit.getDefaultToolkit().getScreenSize();
        screen_width = screen_size.width;
        screen_height = screen_size.height;
      } catch (AWTException e) {
        e.printStackTrace();
      }
    } catch (RuntimeException re) {
      println(re);
    }
  }

  @Override
  public void draw() {
    if (display_framerate && frameCount % 30 == 0) {
      println("Frame rate: " + frameRate);
    }

    if (cam.available()) {
      cam.read();
      cam.loadPixels();
      flipImage(cam.pixels, CAM_WIDTH, CAM_HEIGHT);

      moments_tracker.update(cam.pixels);
      Point tracker_center = moments_tracker.getLastPoint();
      if (range_calibration_on) {
        tracker_history.add(tracker_center);
      }
      int tracker_mbr_width = max(20, ceil(moments_tracker.getMbr_width()));
      int tracker_mbr_height = max(20, ceil(moments_tracker.getMbr_height()));
      search_window.update(cam.pixels, tracker_center.x, tracker_center.y, tracker_mbr_width, tracker_mbr_height);
      gesture_recognizer.update(moments_tracker.getTracker_history());

      pushMatrix();
      // quadrant II: the camera image with superimposed tracker
      image(cam, 0, 0);
      moments_tracker.draw_tracker();

      // quadrant I: difference image with superimposed tracker
      translate(CAM_WIDTH, 0);
      moments_tracker.draw_difference_img();
      moments_tracker.draw_tracker();

      // quadrant IV: tracing of the tracker
      translate(0, CAM_HEIGHT);
      moments_tracker.draw_tracker_tracer();
      //gesture_recognizer.draw_gesture();
      rectMode(CORNERS);
      stroke(0, 180);
      fill(50, 230, 50, 100);
      rect(tracker_min.x, tracker_min.y, tracker_max.x, tracker_max.y);

      // quadrant III: search window
      translate(-CAM_WIDTH, 0);
      fill(0);
      rectMode(CORNER);
      rect(0, 0, CAM_WIDTH, CAM_HEIGHT);
      PImage search_window_img = new PImage(search_window.getWidth(), search_window.getHeight());
      search_window_img.pixels = search_window.getPixels();
      image(search_window_img, search_window.getLeftBound(), search_window.getUpperBound());
      search_window.draw_tracker();

      popMatrix();

      // draw over the control area
      fill(BACKGROUND);
      rect(CAM_WIDTH * 2, 0, CONTROL_WIDTH, CAM_HEIGHT * 2);

      // use to control system
      if (robot_on) {
        Point adjusted_tracker = new Point(tracker_center.x - tracker_min.x, tracker_center.y - tracker_min.y);
        int screen_x = (int) (1.0 * adjusted_tracker.x / (tracker_max.x - tracker_min.x) * screen_width);
        int screen_y = (int) (1.0 * adjusted_tracker.y / (tracker_max.y - tracker_min.y) * screen_height);
        robot.mouseMove(screen_x, screen_y);
        if (screen_x > 2 * screen_width / 3) {
          robot.keyPress(KeyEvent.VK_DOWN);
          robot.keyRelease(KeyEvent.VK_DOWN);
        } else if (screen_x < screen_width / 3) {
          robot.keyPress(KeyEvent.VK_UP);
          robot.keyRelease(KeyEvent.VK_UP);
        }
      }
    }
  }

  private void setupControls() {
    int corner_x = CAM_WIDTH * 2 + CONTROL_WIDTH / 6;
    int corner_y = CONTROL_WIDTH / 6;
    int size = 20;
    controlP5.addToggle("smooth_toggle", false, corner_x, corner_y, size, size);
    corner_y += size * 2;
    controlP5.addToggle("range_calibration", false, corner_x, corner_y, size, size);
    corner_y += size * 2;
    controlP5.addTextlabel("robot_text", "Press 'R' for Robot mode", corner_x, corner_y);
  }

  private void range_calibration() {
    if (range_calibration_on) {
      range_calibration_on = false;
      println("Range calibration is now off. Your range of motion will display as a rectangle.");
      tracker_max = new Point(0, 0);
      tracker_min = new Point(CAM_WIDTH, CAM_HEIGHT);
      for (Point tl : tracker_history) {
        if (tl.x > tracker_max.x) {
          tracker_max.x = tl.x;
        }
        if (tl.y > tracker_max.y) {
          tracker_max.y = tl.y;
        }
        if (tl.x < tracker_min.x) {
          tracker_min.x = tl.x;
        }
        if (tl.y < tracker_min.y) {
          tracker_min.y = tl.y;
        }
      }
      tracker_history.clear();
    } else {
      println("Range calibration is now on. Move around and I will learn your range of motion. Toggle me again when done.");
      range_calibration_on = true;
    }
  }

  private void smooth_mode(boolean value) {
    moments_tracker.setSmoothDifferencing(value);
  }

  public void keyPressed() {
    if (key == 'r' || key == 'R') {
      robot_on = !robot_on;
    }
  }
  // Horizontally flips the pixels array passed to it
  public void flipImage(int[] pixels, int width, int height) {
    int temp, pos, pos2;
    for (int row = 0; row < height; ++row) {
      for (int col = 0; col < width / 2; ++col) {
        pos = row * width + col;
        pos2 = (row + 1) * width - 1 - col;
        temp = pixels[pos];
        pixels[pos] = pixels[pos2];
        pixels[pos2] = temp;
      }
    }
  }
}