package camteraction;

// Takes a list of Points and returns a gesture or null
import java.awt.Point;
import java.util.LinkedList;
import processing.core.PApplet;

public class GestureRecognizer {

  private PApplet p5;
  LinkedList<Point> tracker_displacements;

  public GestureRecognizer(PApplet parent) {
    p5 = parent;
    tracker_displacements = new LinkedList<Point>();
  }
  // TODO: for now, void. should return a gesture or null
  public void update(LinkedList<Point> tracker_positions) {
    Point prev = tracker_positions.getFirst();
    for (Point cur : tracker_positions) {
      tracker_displacements.addLast(new Point(cur.x - prev.x, cur.y - prev.y));
      prev = cur;
      if (tracker_displacements.size() > tracker_positions.size()) {
        tracker_displacements.removeFirst();
      }
    }
  }

  public void draw_gesture() {
    for (Point cur : tracker_displacements) {
      //p5.print("(" + cur.x + "," + cur.y + ")");
    }
    //p5.println();
  }
}
