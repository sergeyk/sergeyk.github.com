package camteraction;

import processing.core.*;

public class SearchWindow {

  private int[] pixels;
  private int width,  height;
  private int left_bound,  right_bound,  upper_bound,  lower_bound;
  private PApplet p5;

  public int getLeftBound() {
    return left_bound;
  }

  public int getUpperBound() {
    return upper_bound;
  }

  public int getWidth() {
    return width;
  }

  public int getHeight() {
    return height;
  }

  int[] getPixels() {
    return pixels;
  }

  public SearchWindow(PApplet parent) {
    p5 = parent;
  }

  public void update(int[] cam_pixels, int xc, int yc, int mbr_width, int mbr_height) {
    left_bound = Math.max(xc - mbr_width, 0);
    right_bound = Math.min(xc + mbr_width, Main.CAM_WIDTH);
    upper_bound = Math.max(yc - mbr_height, 0);
    lower_bound = Math.min(yc + mbr_height, Main.CAM_HEIGHT);
    width = right_bound - left_bound;
    height = lower_bound - upper_bound;
    pixels = get_search_window_pixels(cam_pixels);
  }
  
  public void draw_tracker() {
    int brightestX = 0; // X-coordinate of the brightest video pixel
    int brightestY = 0; // Y-coordinate of the brightest video pixel
    float brightestValue = 0; // Brightness of the brightest video pixel
    // Search for the brightest pixel: For each row of pixels in the video image and
    // for each pixel in the yth row, compute each pixel's index in the video
    int index = 0;
    for (int y = 0; y < height; y++) {
      for (int x = 0; x < width; x++) {
        // Get the color stored in the pixel
        int pixelValue = pixels[index];
        // Determine the brightness of the pixel
        float pixelBrightness = p5.brightness(pixelValue);
        // If that value is brighter than any previous, then store the
        // brightness of that pixel, as well as its (x,y) location
        if (pixelBrightness > brightestValue) {
          brightestValue = pixelBrightness;
          brightestY = y;
          brightestX = x;
        }
        index++;
      }
    }
    // Draw a large, yellow circle at the brightest pixel
    p5.fill(255, 204, 0, 128);
    p5.ellipse(left_bound + brightestX, upper_bound + brightestY, 20, 20);
  }

  private int[] get_search_window_pixels(int[] pixels) {
    int[] window_pixels = new int[width * height];
    for (int row = upper_bound; row < lower_bound; ++row) {
      for (int col = left_bound; col < right_bound; ++col) {
        int window_pos = (row - upper_bound) * width + (col - left_bound);
        int pixel_pos = row * Main.CAM_WIDTH + col;
        window_pixels[window_pos] = pixels[pixel_pos];
      }
    }
    return window_pixels;
  }
}
