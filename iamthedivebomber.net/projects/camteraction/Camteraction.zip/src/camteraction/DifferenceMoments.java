package camteraction;

import java.awt.Point;
import java.util.LinkedList;
import processing.core.*;

public class DifferenceMoments {

  // CONSTANTS
  public static final int FRAMES_BUFFER_SIZE = 3;
  public static final int HISTORY_SIZE = 12;
  // VARIABLES
  private int difference_pixels_threshold;
  public int difference_threshold;
  public boolean smooth_differencing = false;
  private boolean motion = false;
  // OBJECTS
  PApplet p5;
  private int[] difference_pixels;
  private LinkedList<int[]> frames_buffer;
  private int width,  height;
  private float theta;
  private float l1,  l2;
  private float mbr_width,  mbr_height;  // radiuses
  private LinkedList<Point> tracker_history;
  private int current_max_intensity;
  private double average_intensity;

  public LinkedList<Point> getTracker_history() {
    return tracker_history;
  }

  public DifferenceMoments(PApplet owner, int width, int height) {
    p5 = owner;
    this.width = width;
    this.height = height;
    tracker_history = new LinkedList<Point>();
    tracker_history.addFirst(new Point(0, 0));
    frames_buffer = new LinkedList<int[]>();
    frames_buffer.addFirst(new int[width * height]);
    difference_pixels = new int[width * height];
    difference_pixels_threshold = (int) (width * height * 0.04);
  }

  public void update(int[] current_pixels) {
    // update difference_pixels and get the number of pixels changed
    int num_different_pixels = update_difference_pixels(current_pixels, smooth_differencing);

    if (num_different_pixels > difference_pixels_threshold) {
      float sum00, sum10, sum20, sum11, sum01, sum02;
      sum00 = sum10 = sum20 = sum11 = sum01 = sum02 = 0.0f;
      for (int row = 0; row < height; ++row) {
        for (int col = 0; col < width; ++col) {
          int pos = row * width + col;
          int currR = color(difference_pixels[pos], 'R');
          int currG = color(difference_pixels[pos], 'G');
          int currB = color(difference_pixels[pos], 'B');
          float intensity = (1.0f * (currR + currG + currB)) / current_max_intensity;
          sum00 += intensity;
          sum10 += col * intensity;
          sum20 += col * col * intensity;
          sum11 += row * col * intensity;
          sum01 += row * intensity;
          sum02 += row * row * intensity;
        }
      }

      if (sum20 > Float.MAX_VALUE || sum02 > Float.MAX_VALUE || sum11 > Float.MAX_VALUE) {
        throw new RuntimeException("Invalid calculation of moments: exceeding max Float value");
      }

      int xc = Math.round((sum10 / sum00));
      int yc = Math.round((sum01 / sum00));

      motion = false;
      if (xc > 0 && yc > 0) {
        motion = true;

        int a = Math.round((sum20 / sum00)) - xc * xc;
        int b = 2 * (Math.round((sum11 / sum00)) - xc * yc);
        int c = Math.round((sum02 / sum00)) - yc * yc;
        theta = PApplet.atan2(b, (a - c)) / 2;
        l1 = PApplet.sqrt(6 * ((a + c) + PApplet.sqrt(b * b + (a - c) * (a - c))));
        l2 = PApplet.sqrt(6 * ((a + c) - PApplet.sqrt(b * b + (a - c) * (a - c))));

        float radius1x = l1 / 2 * PApplet.cos(theta + PConstants.PI);
        float radius1y = l1 / 2 * PApplet.sin(theta + PConstants.PI);
        float radius2x = l2 / 2 * PApplet.cos(theta - PConstants.PI / 2);
        float radius2y = l2 / 2 * PApplet.sin(theta - PConstants.PI / 2);

        mbr_width = PApplet.abs(radius1x) + PApplet.abs(radius2x);
        mbr_height = PApplet.abs(radius1y) + PApplet.abs(radius2y);

        tracker_history.addFirst(new Point(xc, yc));
        if (tracker_history.size() > HISTORY_SIZE) {
          tracker_history.removeLast();
        }
      }
    }
  }

  // takes in current_pixels as the current frame and updates the difference_image
  // field. returns the number of different pixels
  private int update_difference_pixels(int[] current_pixels, boolean smooth) {
    int num_pixels = width * height;
    int num_different = 0;
    int[] current_copy = new int[num_pixels];
    int[] oldest = (smooth) ? frames_buffer.getLast() : frames_buffer.getFirst();
    difference_threshold = (smooth) ? (int) (0.1 * average_intensity) : (int) (0.5 * average_intensity);
    current_max_intensity = 0;
    double total_intensity = 0;

    for (int i = 0; i < num_pixels; ++i) {
      current_copy[i] = current_pixels[i];

      int currR = color(current_pixels[i], 'R');
      int currG = color(current_pixels[i], 'G');
      int currB = color(current_pixels[i], 'B');
      int currSum = currR + currG + currB;

      total_intensity += currSum;
      if (currSum > current_max_intensity) {
        current_max_intensity = currSum;
      }

      int prevR = color(oldest[i], 'R');
      int prevG = color(oldest[i], 'G');
      int prevB = color(oldest[i], 'B');
      int divisor = (smooth) ? 3 : 1;

      int diffR = Math.abs(currR - prevR) / divisor;
      int diffG = Math.abs(currG - prevG) / divisor;
      int diffB = Math.abs(currB - prevB) / divisor;

      // update the difference image
      if (diffR + diffG + diffB > difference_threshold) {
        ++num_different;
        int difference = 0xff000000 | (diffR << 16) | (diffG << 8) | diffB;
        difference_pixels[i] = difference;
      } else {
        difference_pixels[i] = 0;
      }
    }

    average_intensity = total_intensity / num_pixels;
    frames_buffer.addFirst(current_copy);
    if (!smooth) {
      frames_buffer.removeLast();
    } else if (smooth && (frames_buffer.size() > FRAMES_BUFFER_SIZE)) {
      frames_buffer.removeLast();
    }
    return num_different;
  }
  // draws an ellipse at the last valid tracker location
  // draws a moments rectangle and its MBR if the current frame has motion
  public void draw_tracker() {
    Point last_stable = tracker_history.peek();
    if (motion) {
      p5.pushMatrix();
      p5.translate(last_stable.x, last_stable.y);
      // minimal bounding rectangle:
      p5.rectMode(PConstants.RADIUS);
      p5.stroke(0);
      p5.fill(255, 100, 60, 40);
      p5.rect(0, 0, mbr_width, mbr_height);
      p5.rotate(theta + PConstants.PI);
      // moments rectangle:
      p5.rectMode(PConstants.CENTER);
      p5.stroke(255);
      p5.noFill();
      p5.rect(0, 0, l1, l2);
      p5.popMatrix();
    }
    p5.noStroke();
    p5.fill(255, 200);
    p5.ellipse(last_stable.x, last_stable.y, 40, 40);
  }

  public void draw_tracker_tracer() {
    p5.noStroke();
    p5.fill(255);
    p5.rectMode(PConstants.CORNER);
    p5.rect(0, 0, width, height);
    int alpha = 255;
    for (Point p : tracker_history) {
      p5.fill(0, 100, 66, alpha);
      p5.ellipse(p.x, p.y, 10, 10);
      alpha -= 20;
    }
  }

  public void draw_difference_img() {
    PImage difference_img = new PImage(width, height);
    difference_img.pixels = difference_pixels;
    p5.image(difference_img, 0, 0);
  }

  // returns the 0-255 value of the given color channel for the pixel
  // using a fast bitwise operation
  private int color(int pixel, char color) {
    int shift;
    if (color == 'R') {
      shift = 16;
    } else if (color == 'G') {
      shift = 8;
    } else if (color == 'B') {
      shift = 0;
    } else {
      throw new IllegalArgumentException("char color is not one of 'R', 'G', 'B'");
    }
    return (pixel >> shift) & 0xFF;
  }

  public Point getLastPoint() {
    return tracker_history.peek();
  }

  public float getMbr_width() {
    return mbr_width;
  }

  public float getMbr_height() {
    return mbr_height;
  }

  public void setSmoothDifferencing(boolean value) {
    smooth_differencing = value;
  }
}