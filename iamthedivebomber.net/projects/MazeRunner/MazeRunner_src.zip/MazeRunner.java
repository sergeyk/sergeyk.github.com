import java.io.PrintWriter;

/**
 *  Abstract base class for MazeRunners.  It has a solveMaze method
 *  that, given a maze, will attempt to find a path from the start to
 *  the goal in the maze.
 */
public abstract class MazeRunner {
  /**
   * Attempts to find a path from the start to the donut node of
   * the maze given in <code>maze</code>
   *
   * @param maze  The maze to solve.
   * @param writer The printwriter on which to output the
   *    maze solution.
   */
  public abstract void solveMaze(Maze maze, PrintWriter writer);
}

// >sergey:
// notes:
/*
After solving a maze, your MazeRunner should output a solution path calculated by the search.
The path should be given on a single line and should consist of the printed locations
(using the built-in print method) from the start to the exit, separated by single spaces.
On the next line should be the length of the solution path, and on the following line
should be the number of nodes visited and expanded in the search. The solution should
be preceeded by a line giving the name of the search algorithm used. For example, the
output for the above maze might be:
 
Random Search
(0,0) (0,1) (0,2) (0,3) (1,3) (2,3) (2,4) (3,4) (4,4) (4,5) (4,6)
Length of Path: 10
Number Nodes Visited: 15
*/