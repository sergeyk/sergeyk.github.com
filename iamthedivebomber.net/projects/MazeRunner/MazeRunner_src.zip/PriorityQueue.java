/**
 * Base interface for priority queue implementations, using generics. 
 * Throw exceptions as appropriate. 
 */
public interface PriorityQueue<E extends Comparable<? super E>> {
  /**
   * Returns true if priority queue has no elements
   *
   * @return  true if the priority queue has no elements
   */
  public boolean isEmpty();

  /**
   * Returns a reference to the minimum element in the priority queue
   *
   * @return  reference to the minimum element in the priority queue.
   */
  public E findMin();

  /**
   * Inserts a new object to the priority queue
   *
   * @param x Object to be inserted into the priority queue.
   */
  public void insert(E x);

  /**
   * Removes the minimum element from the priority queue.
   *
   * @return  reference to the minimum element.
   */
  public E deleteMin();

  /**
   * Erases all elements from the priority queue.
   */
  public void makeEmpty();
}