import processing.core.*;

import java.util.*;
import java.io.*;

public class Visualizer extends PApplet implements MazeChangeListener{
  
  private static final int BACKGROUND = 240;
	private int updateInterval = 13; //15
  private int cellSize;
  private MazeRunner runner;
  private SquareCellMaze maze;
  private boolean canClick = false;
  private int numClick;
  private Queue<String> mazeQueue;
  
  public void setup() {
  	// set up the canvas
    size(500, 300);
    background(BACKGROUND);
    smooth();
    setupQueue();
		setupMaze(getMaze());
		loop();
  }
  
  private void setupQueue() {
  	mazeQueue = new MazeQueue<String>();
  	mazeQueue.enqueue("bigmaze4.txt");
  	mazeQueue.enqueue("bigmaze3.txt");
  	mazeQueue.enqueue("nocycles1.txt");
  	mazeQueue.enqueue("maze4.txt");
	}
  
  private String getMaze() {
  	String file = mazeQueue.dequeue();
  	mazeQueue.enqueue(file);
  	return file;
  }

	private void setupMaze(String fileName) {
  	// TODO: must be a better way
		try {
			try {
				maze = new SquareCellMaze();
				maze = maze.parseMaze(openStream(fileName));
				drawMaze(maze);
				maze.addMazeChangeListener(this);
				canClick = true;
			} catch (FileNotFoundException fnfe) { System.err.println(fnfe); }
		} catch (IOException ioe) { System.err.println(ioe); }
  }
  
  // on each mouse press, a different runner is initialized that runs the maze
  // 1: dfs
  // 2: bfs
  // 3: bestfirst
  // 4: A*
  // on a click after that, a new maze is read (or generated, potentially)
  // TODO: generate a maze with clicks before starting
  public void mousePressed() {
  	if(canClick) {
  		numClick++;
  		switch (numClick) {
	  		case 1: runner = new DFSMazeRunner(); break;
	  		case 2: runner = new BFSMazeRunner(); break;
	  		case 3: runner = new BestFirstMazeRunner("bin"); break;
	  		case 4: runner = new AStarMazeRunner(); break;
	  		case 5: runner = null; background(BACKGROUND); setupMaze(getMaze()); numClick = 0; break;
	  		default: System.err.println("Unsupported click!");
  		}	  	
	  	if (runner != null) {
	  		Thread mrt = new Thread(new MazeRunnerThread(maze, runner));
	  		drawMaze(maze);
		  	mrt.start();
	  	}
  	}
  }
  
  // processing method that updates the applet.
  // we only update when prompted, so no need for code here.
  public void draw() {}
  
  // figures out optimal cell size, then
  // iterates over all cells in maze and draws them in order
  public void drawMaze(SquareCellMaze maze) {
    // first, figure out optimal cell size
    int mWidth = maze.getWidth() + 2;
    int mHeight = maze.getHeight() + 2;
    cellSize = Math.min(width / mWidth, height / mHeight);
    
    // send each cell to drawCell()
    Iterator it = maze.getCells();
    while(it.hasNext()) {
      drawCell((SquareCellMaze.SquareCell)it.next());
    }
  }
  
  // takes the cell sent to it and draws its outline and walls,
  // and a donut or start circle if it has that
  private void drawCell(SquareCellMaze.SquareCell c) {   
    // figure out the corners
    int row = c.getRow();
    int col = c.getCol();
    int topLeftX = cellSize + col*cellSize;
    int topLeftY = cellSize + row*cellSize;
    int topRightX = topLeftX + cellSize;
    int topRightY = topLeftY;
    int bottomLeftX = topLeftX;
    int bottomLeftY = topLeftY + cellSize;
    int bottomRightX = topLeftX + cellSize;
    int bottomRightY = topLeftY + cellSize;
    
    // draw a light gray rectangle around each cell, and 
    // fill the cell with whatever color its state suggests
    stroke(218);
    if (c.getState() == MazeCell.CellState.notVisited)
      fill(255); // white (clear)
    else if (c.getState() == MazeCell.CellState.visited)
      fill(190); // gray
    else if (c.getState() == MazeCell.CellState.visitInProgress)
      fill(237,26,26); // red
    else if (c.getState() == MazeCell.CellState.examined)
      fill(30,229,255); // blue
    else if (c.getState() == MazeCell.CellState.solutionPath)
      fill(239,255,30); // yellow
    rect(topLeftX,topLeftY,cellSize,cellSize);
    
    // draw the walls
    strokeWeight(2);
    stroke(0);
    if (c.isWall(Direction.north))
      line(topLeftX,topLeftY,topRightX,topRightY);
    if (c.isWall(Direction.east))
      line(topRightX,topRightY,bottomRightX,bottomRightY);
    if (c.isWall(Direction.south))
      line(bottomLeftX,bottomLeftY,bottomRightX,bottomRightY);
    if (c.isWall(Direction.west))
      line(topLeftX,topLeftY,bottomLeftX,bottomLeftY);
      
    // draw the start and donut circles
    if (c.isStart()) {
      strokeWeight(1);
      ellipseMode(CORNER);
      fill(64,234,43);
      ellipse(topLeftX+2,topLeftY+2,cellSize-5,cellSize-5);
    }
    else if (c.isDonut()) {
      strokeWeight(1);
      ellipseMode(CORNER);
      fill(255,248,18);
      ellipse(topLeftX+2,topLeftY+2,cellSize-5,cellSize-5);
    }
  }
  
  // this is what tells the applet to update a cell in the maze.
  // after it does so, it sleeps for updateInterval
  public void cellStateChangeEvent(MazeCell cell) {
    drawCell((SquareCellMaze.SquareCell) cell);
    interval(updateInterval);
  }

  // This function is called when the general state of the maze
  // has been changed.
  public void stateChangeEvent() {
  	if (maze.working)
  		canClick = false;
  	else
  		canClick = true;
  }
  
  // sleep for the length of time passed
  public void interval(int num) {
    try {
      Thread.sleep(num);
    } catch(InterruptedException ie) {
      System.err.println(ie.getMessage());
    }
  }
}