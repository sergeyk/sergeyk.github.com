/* Sergey Karayev and Victoria Kirst
 * CSE 326 -- Summer 2007
 * Project 2C (modified from 2A on 07.24.07)
 * MazeStack is an "any type" stack that implements the Stack<E> interface.
 * Grows and shrinks automatically.
 */

public class ArrayStack<E> {

  public static final int INIT_SIZE = 200; // initial size of stack
  private Object[] array;                  // array in which stack is stored
  private int index;                       // index of top of stack; -1 if
  // stack is empty

  public ArrayStack() {
    array =  new Object[INIT_SIZE];
    index = -1;
  }

  // returns true is stack has no elements
  public boolean isEmpty() {
    return (index < 0);
  }

  //  gets and returns the most recently pushed item in the stack
  // throws UnderflowException is stack empty
  public E top() {
    if (isEmpty())
      throw new UnderflowException("Operation on empty stack.");
    return (E) array[index];
  }

  // returns and removes the most recently pushed item from the stack
  // throws UnderflowException is stack empty
  public E pop() {
    if (isEmpty())
      throw new UnderflowException("Operation on empty stack.");
    Object retValue = array[index];
    index--;
    /*
    if (index == array.length/4) {
      Object[] temp = new Object[array.length / 2];
      for (int i = 0; i < index; i++)
        temp[i] = array[i];
      array = temp;
    }
    */
    return (E) retValue;
  }

  // inserts new item into the stack
  public void push(E x) {
    index++;
    if (index == array.length) {
      Object[] temp = new Object[array.length * 2];
      for (int i = 0; i < index; i++)
        temp[i] = array[i];
      array = temp;
    }
    array[index] = x;
  }

  // erases all elements from the stack
  public void makeEmpty() {
    index = -1;
  }
}
