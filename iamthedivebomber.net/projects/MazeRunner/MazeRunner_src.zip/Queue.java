/**
 * Base interface for queue implementations, using generics.
 */
public interface Queue<E> {
  /**
   * Returns true if queue has no elements
   *
   * @return  true if the  queue has no elements
   */
  public boolean isEmpty();

  /**
   * Enqueues a new object to the queue
   *
   * @param x Object to be enqueued into the queue.
   */
  public void enqueue(E x);

  /**
   * Get the least recently inserted item in the queue.
   * Does not alter the queue.
   *
   * @return  The front of the queue.
   * @exception UnderflowException Thrown if queue is empty.
   */
  public E peek();

  /**
   * dequeues the front of the queue.
   *
   * @return  The front of the queue.
   * @exception UnderflowException Thrown if queue is empty.
   */
  public E dequeue();

  /**
   * Erases all elements from the queue.
   */
  public void makeEmpty();
}