import java.io.*;
import java.util.*;

// Victoria Kirst and Sergey Karayev
// CSE 326 -- Summer 2007
// Project 2B -- Maze Generator class

// This is a function object consisting of a method to generate a maze
// and output the maze as a text file called "random_maze.txt"
public class MazeGenerator {

    // Generates a maze of size (length x width) into a file "random_maze.txt"
    // Throws IllegalArgumentException if given length or width <= 0
    public void generateMaze(int length, int width) throws FileNotFoundException{
	if (length <= 0 || width <= 0) {
	    throw new IllegalArgumentException("Length and width must be > 0");
	}
	
	PrintStream out = new PrintStream(new File("random_maze.txt"));

	// First print out length and width
	out.println(length + " " + width);

	char[][] grid = new char[2*width + 1][2*length + 1];
	
	// Fill matrix with symbols
	for (int i = 0; i < 2*width + 1; i++) {
	    // even i's  draw "+-" pattern
	    if (i % 2 == 0) {
		grid[i][0] = '+';
		for(int j = 1; j <= 2*length; j +=2) {
		    grid[i][j] = '-';
		    grid[i][j + 1] = '+';
		}
	    } else {
		grid[i][0] = '|';
		for (int j = 1; j <= 2*length; j +=2) {
		    grid[i][j] = ' ';
		    grid[i][j + 1] = '|';
		}
	    }
	}

	// Grid Notes:
	// grid[0][*] and grid[*][0] and grid[2*width][*] and grid[*][2*length]
	// are all borders; MUST be in grid!

	// Holes are the odd length/j values from 1 to length inclusive

	Random r = new Random();
	
	// Set entrance:
	int enterX = r.nextInt(length) + 1;
	int enterY = r.nextInt(width) + 1;

	int exitX;
	int exitY;

	do {
	    exitX = r.nextInt(length) + 1;
	} while (enterX == exitX);

	do {
	    exitY = r.nextInt(width) + 1;
	} while (enterY == exitY);

	// Convert (x,y) to (i,j) in grid
	enterX = enterX * 2 - 1;
	enterY = enterY * 2 - 1;
	exitX = exitX * 2 - 1;
	exitY = exitY * 2 - 1;

	grid[enterY][enterX] = 'O';
	grid[exitY][exitX] = '*';
	
	// Create path to exit
	int i = enterY;
	int j = enterX;
	
	do {
	    // Choose random direction
	    // 0 = up, 1 = right; 2 = down; 3 = left
	    int dir = r.nextInt(4);
	    int targetX = j;
	    int targetY = i;

	    switch (dir) {
	    case 0: // go up
		targetY--;
		if (targetY != 0) {
		    grid[targetY][j] = ' '; // get rid of wall
		    i -= 2; // decrement i
		}
		break;
	    case 1: // go right
		targetX++;
		if (targetX != 2*length) {
		    grid[i][targetX] = ' '; // get rid of wall
		    j += 2; // increment j
		}
		break;
	    case 2: // go down
		targetY++;
		if (targetY != 2*width) {
		    grid[targetY][j] = ' '; // get rid of wall
		    i += 2; // increment i
		}
		break;
	    case 3: // go left
		targetX--;
		if (targetX != 0) {
		    grid[i][targetX] = ' '; // get rid of wall
		    j -= 2; // decrement j
		}
		break;
	    }
	} while (i != exitY || j != exitX);

	
	// Randomly tear down walls
	// Each wall has a 66% chance to be torn down
	for (int k = 1; k < 2*width; k++) {
	    if (k % 2 == 0) {
		for(int h = 1; h < 2*length; h +=2) {
		    int tear = r.nextInt(6);
		    if (tear == 0 || tear == 1)
			grid[k][h] = ' ';
		}
	    } else {
		for (int h = 1; h < 2*length; h +=2) {
		    int tear = r.nextInt(6);
		    if (tear == 0 || tear == 1)
			grid[k][h] = ' ';
		}
	    }
	}
	
	// Reprint the entrance and exit in case they got erased
	grid[enterY][enterX] = 'O';
	grid[exitY][exitX] = '*';

	// Print matrix to file
	for (int k = 0; k < 2*width + 1; k++) {
	    for (int h = 0; h < 2*length + 1; h++) {
		out.print(String.valueOf(grid[k][h]));
	    }
	    out.println();
	}
    }
}