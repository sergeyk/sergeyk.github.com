/* Sergey Karayev and Victoria Kirst
 * CSE 326 -- Summer 2007
 * Project 2B
 * BinomialQueue is an "any type" binomial queue that implements the
 * PriorityQueue interface.
 */

public class BinomialQueue<E extends Comparable<E>> implements PriorityQueue<E> {

    // Node represent the nodes in the binomial queue
    private static class Node<E> {
	public Node(E data) {
	    this(data, null, null);
	}
	
	public Node (E data, Node<E> leftChild, Node<E> nextSibling) {
	    this.data = data;
	    this.leftChild = leftChild;
	    this.nextSibling = nextSibling;
	}

	public E data;               // Data in the node
	public Node<E> leftChild;    // Left child
	public Node<E> nextSibling;  // Right child
    }

    private static final int DEFAULT_TREES = 1; // Initial number of trees

    private int size;                  // # items in a priority queue
    private Object [] forest;          // Array of tree roots

    // Constructs empty BinomialQueue of default size
    public BinomialQueue() {
	forest = new Object[DEFAULT_TREES];
	size = 0;
    }
    
    // Constructs a BinomialQueue with size of 1, containing a
    // node that stores the given data item.
    public BinomialQueue(E item) {
	forest = new Object[DEFAULT_TREES];
	size = 1;
	forest[0] = new Node<E>(item);
    }

    // Merges given BinomialQueue with this BinomialQueue
    public void merge(BinomialQueue<E> rhs) {

	// Check to avoid self-reference
	if (this == rhs)
	    return;

	// Update size
	size += rhs.size;

	// Expansion check
	if (size > capacity()) {
	    int maxLength = Math.max (forest.length, rhs.forest.length);
	    expandForest (maxLength + 1);
	}

	// Carry is initially null
	Node<E> carry = null;

	// i iterates through the index of the forest
	// j iterates through how many items the forest contains (increasing
	// quadraticly)
	for (int i = 0, j = 1; j <= size; i++, j*=2) {
       
	    // Gets tree at this index i
	    Node<E> t1 = (Node<E>) forest[i];
	    // Gets tree at this index i
	    Node<E> t2 = i < rhs.forest.length ?(Node<E>) rhs.forest[i] : null;
	    
	    // Determines 8 cases; will label with number 0 - 7
	    int mergeCase = t1 == null ? 0 : 1;
	    mergeCase += t2 == null ? 0 : 2;
            mergeCase += carry == null ? 0 : 4;
 
	    switch (mergeCase) {
	    
	    case 0: // no trees in either at this particular index
	    case 1: // Only this tree; don't merge
		break;
	    case 2: // Only rhs; simply merge into this forest
		forest[i] = t2;
		rhs.forest[i] = null;
		break;
	    case 4: // Only carry; simply merge into this forest
		forest[i] = carry;
		carry = null;
		break;
	    case 3: // this and rhs; combine and create carry
		carry = combineTrees(t1, t2);
		forest [i] = rhs.forest[i] = null;
		break;
	    case 5: // this and carry; combine and create carry
		carry = combineTrees(t1, carry);
		forest[i] = null;
		break;
	    case 6: // rhs and carry; combine and create carry
		carry = combineTrees(t2, carry);
		rhs.forest[i] = null;
		break;
	    case 7: // all three; add carry to forest, then combine
		    // and carry on others
		forest[i] = carry;
		carry = combineTrees(t1, t2);
		rhs.forest[i] = null;
		break;
	    }
	} // end for-loop

	// Ensure that given forest rhs is empty
	for (int k = 0; k < rhs.forest.length; k++) 
	    rhs.forest[k] = null;
	rhs.size = 0;
    }

    // Inserts given item x into forest
    public void insert (E x) {
	merge( new BinomialQueue<E> (x) );
    }

    // Finds and returns minimum item in BinomialQueue
    // Does not change BinomialQueue
    public E findMin() {
   	int minIndex = findMinIndex();
	return (E) forest[minIndex];
    }

    // Deletes and returns miminum item from BinomialQueue
    public E deleteMin() {
	if (isEmpty())
	    throw new UnderflowException();

	// Find min item
	int minIndex = findMinIndex();
	E minItem = (E) ((Node<E>) forest[minIndex]).data;

	//  Construct H'', a forest composed of the deleted node's now-orphaned
 	// children
	Node<E> deletedTree = (Node<E>) ((Node<E>) forest[minIndex]).leftChild;
	
	BinomialQueue<E> deletedQueue = new BinomialQueue<E>();

	// Set capacity, size of new H''
	deletedQueue.expandForest(minIndex + 1);
	deletedQueue.size = (1 << minIndex) -1;

	// Place each orphaned child into forest
	for (int j = minIndex - 1; j >= 0; j--) {
	    deletedQueue.forest[j] = deletedTree;
	    // Move to next child
	    deletedTree = deletedTree.nextSibling; 
	    ( (Node<E>) deletedQueue.forest[j]).nextSibling = null;
	}

	// "Construct" H', original forest without min
	// Replace min index with null and update size
	forest[minIndex] = null;
	size -= deletedQueue.size + 1;

	// Merge H'' into H'
	merge (deletedQueue);

	return minItem;
    }

    // Returns true if queue is empty, false otherwise
    public boolean isEmpty() {
	return size == 0;
    }
    
    // Resets current BinomialQueue to an empty forest of default number
    // of trees
    public void makeEmpty() {
	forest = new Object[DEFAULT_TREES];
	size = 0;
    }

    // Expands the forest to a forest of given size n (array size, not
    // capacity)
    private void expandForest (int n) {
	
	Object[] newForest =  new Object[n];
	    
	// Copies previous entries into new array
	for (int i = 0; i < forest.length; i++) {
	    newForest[i] =  forest[i];
	}
	
	// Updates array
	forest = newForest;
    }

    // Combines two trees of equal size by comparing roots and adding
    // the larger of the two roots as the child of the other root.
    // Does not check for equal size of trees.
    private Node<E> combineTrees(Node<E> t1, Node<E> t2) {
	if (( (E) t1.data).compareTo( (E) t2.data) > 0) 
	    return combineTrees(t2, t1);
	t2.nextSibling = t1.leftChild;
	t1.leftChild = t2;
	return t1;
    }

    // Returns the capacity of the forest
    private int capacity() {
	return (1 << forest.length) - 1;
    }

    // Finds the index number of the minimum element in the BinaryQueue
    private int findMinIndex() {
	int minIndex = 0;
	
	// start index at a legal value
	while (forest[minIndex] == null) {
	    minIndex++;
	}
	
	// Stores the first non-null element of the forest as initial min
	E min =(E)((Node<E>) forest[minIndex]).data;

	// Goes through forest, looks for min and minIndex
	for (int i = minIndex; i < forest.length; i++) {
	    if (forest[i] != null) {
		if (((E) min).compareTo( (E) ((Node<E>)forest[i]).data) >= 0) {
		    min = (E) ((Node<E>)forest[i]).data;
		    minIndex = i;
		}
	    }
	}
	return minIndex;
    } 
}
