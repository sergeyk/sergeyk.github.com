/**
 * Base interface for stack implementations, uses generics.  
 */
public interface Stack<E> {
  /**
   * Returns true if stack has no elements
   *
   * @return  true if the stack has no elements
   */
  public boolean isEmpty();

  /**
   * Get the most recently inserted item in the stack.
   * Does not alter the stack.
   *
   * @return the most recently inserted item in the stack.
   * @exception UnderflowException Thrown if stack is empty.
   */
  public E top();

  /**
   * Remove the most recently inserted item from the stack.
   *
   * @exception UnderflowException Thrown if stack is empty.
   */
  public void pop();

  /**
   * Insert a new item into the stack, if not already full.
   *
   * @param x the item to insert.
   */
  public void push( E x );

  /**
   * Erases all elements from the stack.
   */
  public void makeEmpty();
}
