/* Sergey Karayev and Victoria Kirst
 * CSE 326 -- Summer 2007
 * Project 2A
 * ThreeHeap is an "any type" ternary heap that implements the PriorityQueue<E>
 * interface. Changing the constant D can change this ThreeHeap to a D-heap
 * of any D >= 2.
 */

public class ThreeHeap<E extends Comparable<E>> implements PriorityQueue<E> {
  public static final int DEFAULT_CAPACITY = 10; // initial size of queue
  private static final int ROOT_POS = 1;          // index of root
  private static final int D = 3;                 // # of children per node

  private int currentSize;       // Number of elements in heap
  public Object[] array;         // The array in which the heap is stored


  public ThreeHeap() {
    array = new Object[DEFAULT_CAPACITY];
    currentSize = 0;
  }

  /**
   * Returns true if priority queue has no elements
   *
   * @return  true if the priority queue has no elements
   */
  public boolean isEmpty() {
    return currentSize == 0;
  }


  /**
   * Returns a reference to the minimum element in the priority queue
   *
   * @return  reference to the minimum element in the priority queue.
   * @exception     EmptyHeapException     Thrown if heap is empty
   */
  public E findMin() {
    if (isEmpty()) {
      throw new EmptyHeapException("Cannot find min of empty heap");
    }
    return (E) array[ROOT_POS];
  }

  /**
   * Inserts a new object to the priority queue
   *
   * @param x Object to be inserted into the priority queue.
   */
  public void insert(E x) {
    if (currentSize + 1 == array.length)
      enlargeArray(array.length * 2 + 1);

    currentSize++;

    int hole = currentSize;
    while ( hole > ROOT_POS ) {
      E parent = (E) array[(hole + (D - 2) ) /D];

      // if x is less than the parent,
      // percolate up
      if (x.compareTo(parent) < 0) {
        array[hole] = array[(hole + (D - 2) ) /D];
        hole = (hole + (D - 2) ) / D;
      } else { // x >= parent
        break;
      }
    }
    array[hole] = x;
  }

  /**
   * If array is full, enlarges array to passed newSize
   *
   * @param newSize Size of the new array
   * @exception     IllegalArgumentException    Thrown if passed size is less
   *                                            that or equal to current size
   */
  private void enlargeArray(int newSize) {
    if (newSize <= array.length) {
      throw new IllegalArgumentException("New size of array is <=" +
                                         " size of original array");
    }

    Object[] newArray =  new Object[newSize];

    // Copies previous entries into new array
    for (int i = 1; i < array.length; i++) {
      newArray[i] =  array[i];
    }

    // Updates array
    array = newArray;
  }

  /**
   * Removes the minimum element from the priority queue.
   *
   * @return  reference to the minimum element.
   * @exception     EmptyHeapException     Thrown if heap is empty
   */
  public E deleteMin() {
    // Get the top of heap
    E returnElement = findMin();
    // Get the last element in heap to reposition in heap
    E lastElement = (E) array[currentSize];
    currentSize--;
    // The hole is at the top of the heap to begin with
    int hole = ROOT_POS;
    while (D*hole - (D - 2) <= currentSize) {
      // find the smallest child
      int smallerChildIndex = findSmallerChildIndex(D*hole - (D - 2), D);
      // if child is smaller than lastElement
      if (((E) array[smallerChildIndex]).compareTo(lastElement) < 0) {
        // fill hole w/ smaller child
        array[hole] = (E) array[smallerChildIndex];
        hole = smallerChildIndex;
      } else {
        break;
      }
    }
    // Hole is where last element should go
    array[hole] = lastElement;
    return returnElement;
  }

  // looks at the node at pos and the following extent-1 nodes
  // to find the lowest one
  // returns index of lowest child
  private int findSmallerChildIndex(int pos, int extent) {
    int retPos = pos;
    E retValue = (E) array[pos];
    pos++;
    for (int i = 1; i < extent && pos < currentSize +1; i++, pos++) {
      if (((E) array[pos]).compareTo(retValue) < 0) {
        retPos = pos;
        retValue = (E) array[pos];
      }
    }
    return retPos;
  }

  /**
   * Erases all elements from the priority queue.
   */
  public void makeEmpty() {
    array = new Object[DEFAULT_CAPACITY];
    currentSize = 0;
  }
}
