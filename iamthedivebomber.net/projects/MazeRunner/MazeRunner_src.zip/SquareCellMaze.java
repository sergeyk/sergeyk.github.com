import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.StringTokenizer;


/**
 * SquareCellMaze is a Maze of square cells (cells with 4 sides).
 *
 * @author Albert J. Wong (awong@cs)
 */
public class SquareCellMaze extends Maze {
  /**
   * Construct a trivial maze.  This constructor is private
   * because it is essentially meaningless to create a maze that
   * isn't based on a file.  Thus only the SquareCellMazeFactory will
   * be allowed to create a maze.  This makes it so that only
   * inner classes or member methods can call the constructor so
   * we don't have to worry about people creating bad mazes.
   *
   */
  public SquareCellMaze() {
    startCell = null;
    donutCell = null;
    cells = null;
    width = 0;
    height = 0;
  }
  
  /*public void resetCellState() {
    for (int i = 0; i < width; i++)
    	for (int j = 0; j < height; j++) {
    		cells[j][i].state =  MazeCell.CellState.notVisited;
    		cells[j][i].setExtraInfo(null);
    	}
  }*/

  /**
   * Returns a reference to the <code>MazeCell</code> object that
   * is the start cell of the maze.
   *
   * @return The start cell of this maze.
   */
  public MazeCell getStart() {
    return startCell;
  }

  /**
   * Returns a reference to the <code>MazeCell</code> object that
   * is the donut cell of the maze.
   *
   * @return The donut cell of this maze.
   */
  public MazeCell getDonut() {
    return donutCell;
  }

  /**
   * Returns an iterator that will iterate over all cells in this
   * maze.
   *
   * @return an iterator that will iterate over all cells in this
   * maze.
   */
  public Iterator getCells() {
    return new SquareCellMazeIterator();
  }

  /**
   * Returns an iterator that will over all cells in this maze
   * that can be reached from the given cell.
   *
   * @param cell the cell for which the iterator will try to
   * iterator over the neighbors of.
   * @return an iterator that will over all cells in this maze
   * that can be reached from the given cell.
   */
  public Iterator getNeighbors(MazeCell cell) {
    return new NeighborIterator((SquareCell)cell);
  }

  /**
   * Return the number of cells in this maze
   *
   * @return the number of cells in this maze.
   */
  public int getNumCells() {
    return width * height;
  }

  /**
   * An accessor function that returns the cell located at
   * (row,col).  All SquareCellMazes are rectangular matricies so
   * this works.
   *
   * @param row The row of the cell to retrieve.
   * @param col The column of the cell to retrieve.
   * @return  The cell located at (row,col).
   */
  public SquareCell getCell(int row, int col) {
    return cells[row][col];
  }

  /**
   * An mutator function that places a cell at a the location
   * (row,col).  All SquareCellMazes are rectangular matricies so
   * this works.
   *
   * @param row The row to place the cell in.
   * @param col The column to place the cell in.
   * @param cell The cell to place at (row,col).
   */
  private void setCell(int row, int col, MazeCell cell) {
    cells[row][col] = (SquareCell)cell;
  }

  /**
   * Accessor to the get the width, in number of cells, of the
   * SquareCellMaze.
   *
   * @return The width of the maze in number of cells.
   */
  public int getWidth() {
    return width;
  }

  /**
   * Accessor to the get the height, in number of cells, of the
   * SquareCellMaze.
   *
   * @return The height of the maze in number of cells.
   */
  public int getHeight() {
    return height;
  }

  /** A reference to the start cell of this maze. */
  private SquareCell startCell;

  /** A reference to the donut cell of this maze. */
  private SquareCell donutCell;

  /**
   *  A 2 dimentional array that holds/represents all the cells in
   *  this maze.
   */
  private SquareCell[][] cells;

  /** The width of the maze in number of cells. */
  private int width;

  /** The height of the maze in number of cells. */
  private int height;

  /**
   * An iterator class that iterates over all the cells in a
   * SquareCellMaze.  This class is implemented using the inner
   * class language feature in Java which allows an inner (as
   * opposed to nested) class to have an implicit reference to the
   * containing class.  Thus, any SquareCellMazeIterator instance
   * implicitly knows which maze it is associated with. Quite
   * useful for iterators.
   *
   * @author Albert J. Wong (awong@cs)
   */
  private class SquareCellMazeIterator implements Iterator {
    /**
     * Constructs a new SquareCellMazeIterator.
     */
    public SquareCellMazeIterator() {
      curRow = 0;
      curCol = 0;
    }


    /**
     * Returns true if there are still cells to be iterated
     * over, false otherwise.
     *
     * @return true if there are still cells to be iterated
     * over, false otherwise.
     */
    public boolean hasNext() {
      return (curRow+1 != height || curCol != width);
    }


    /**
     * If hasNext() is true, this returns the next cell in
     * the iteration sequence.  Othewrise a
     * NoSuchElementException is thrown.
     *
     * @return the next cell in the iteration sequence
     * @exception NoSuchElementException  Thrown if next()
     *  is called when there are no more elements to be
     *  iterated over.
     */
    public Object next() {
      if( !hasNext() ) {
        throw new NoSuchElementException();
      }

      if(curCol == width) {
        curCol = 0;
        curRow++;
      }

      return cells[curRow][curCol++];
    }


    /**
     * The remove function is not implemented in this
     * iterator and it doesn't make sense to remove a cell
     * from a SquareCellMaze.
     *
     * @exception UnsupportedOperationException Thrown when
     *  remove() is called.
     */
    public void remove() {
      throw new UnsupportedOperationException();
    }

    /** Keeps Track of the current row we are iterating over. */
    private int curRow;

    /** Keeps Track of the current column we are iterating over. */
    private int curCol;
  }

  /**
   * An iterator class that iterates over all neighbors that can
   * be reached from the cell the iterator was created for.  This
   * class is implemented using the inner class language feature
   * in Java which allows an inner (as opposed to nested) class to
   * have an implicit reference to the containing class.  Thus,
   * any SquareCellMazeIterator instance implicitly knows which
   * maze it is associated with. Quite useful for iterators.
   *
   * @author Albert J. Wong (awong@cs)
   */
  private class NeighborIterator implements Iterator {
    /**
     *  Construct a new NeighborIterator that will
     *  iterator over teh neighbors of <code>cell</code>
     *
     *  @param cell The cell whose neighbors this iterator
     *   will iterate over.
     */
    public NeighborIterator( SquareCell cell ) {
      refCell = cell;
      curWall = Direction.north;
    }

    /**
     * Returns true if there are still cells to be iterated
     * over, false otherwise.
     *
     * @return true if there are still cells to be iterated
     * over, false otherwise.
     */
    public boolean hasNext() {
      return numWallsFound < ( refCell.getMaxNumWalls() -
                               refCell.getNumWalls() );
    }

    /**
     * If hasNext() is true, this returns the next cell in
     * the iteration sequence.  Othewrise a
     * NoSuchElementException is thrown.
     *
     * @return the next cell in the iteration sequence
     * @exception NoSuchElementException  Thrown if next()
     *  is called when there are no more elements to be
     *  iterated over.
     */
    public Object next() {
      int nextRow = refCell.getRow();
      int nextCol = refCell.getCol();

      while(hasNext()) {
        if( !refCell.isWall(curWall) ) {
          if( curWall == Direction.north ) {
            nextRow--;
          } else if ( curWall == Direction.east ) {
            nextCol++;
          } else if ( curWall == Direction.south ) {
            nextRow++;
          } else if ( curWall == Direction.west ) {
            nextCol--;
          }

          numWallsFound++;
          curWall = curWall.clockwise90();
          return getCell(nextRow, nextCol);
        }

        curWall = curWall.clockwise90();
      }

      return null;
    }

    /**
     * The remove function is not implemented in this
     * iterator and it doesn't make sense to remove a cell
     * from a SquareCellMaze.
     *
     * @exception UnsupportedOperationException Thrown when
     *  remove() is called.
     */
    public void remove() {
      throw new UnsupportedOperationException();
    }

    /**
     *  The reference to the cell who we are finding the
     *  neighbors of.
     */
    private SquareCell refCell;


    /** The current wall we are examining. */
    private Direction curWall;


    /**
     *  The number of walls we have found for this cell so
     *  far.
     */
    int numWallsFound = 0;
  }

  /**
   * SqureCell is the representation of a Cell in a
   * SquareCellMaze.  It is a nested class (as opposed to an inner
   * class like the Iterators...notice the "static" keyword in the
   * class's delcaration.  This is because a SquareCell does not
   * really need to, and should have no knowledge of the maze it
   * is a part of. (Keeping a strict hierarchy of knowledge makes
   * most OO inheritence hierarchy sane.  Otherwise they blow up
   * like a big big balloon).  This class is nested because,
   * basically, no one else should really have interest in
   * creating a SquareCell.  It's really a property of the
   * SquareCellMaze.
   *
   * @author Albert J. Wong (awong@cs)
   */
  protected static class SquareCell extends MazeCell {
    /**
     * Creates a new SquareCell with the given parameters.
     *
     * @param cellRow The row this cell is on
     *  (yeah, this shouldn't be part of the SquareCell.
     *  But it's soo convenient).
     * @param cellCol The column this cell is on
     *  (yeah, this shouldn't be part of the SquareCell.
     *  But it's soo convenient).
     *
     * @param isStart <code>true</code> if this cell
     *  is the start cell.
     * @param isDonut <code>true</code> if this cell
     *  is the donut cell.
     *
     * @param northWall <code>true</code> if this cell
     *  has a wall to the North.
     * @param eastWall <code>true</code> if this cell
     *  has a wall to the East.
     * @param southWall <code>true</code> if this cell
     *  has a wall to the South.
     * @param westWall <code>true</code> if this cell
     *  has a wall to the West.
     */
    public SquareCell(int cellRow, int cellCol,
                      boolean isStart, boolean isDonut,
                      boolean northWall, boolean eastWall,
                      boolean southWall, boolean westWall) {
      walls = new boolean[] {northWall, eastWall,
                             southWall, westWall};

      numWalls = 0;
      for(int i=0; i < 4; i++) {
        if(walls[i]) {
          numWalls++;
        }
      }

      isStartCell = isStart;
      isDonutCell = isDonut;

      row = cellRow;
      col = cellCol;
    }

    /**
     * Returns true if this cell is a start cell.
     *
     * @return <code>true</code> if this cell is a start cell.
     *  <code>false</code> otherwise.
     */
    public boolean isStart() {
      return isStartCell;
    }

    /**
     * Returns true if this cell is a donut cell.
     *
     * @return <code>true</code> if this cell is a donut cell.
     *  <code>false</code> otherwise.
     */
    public boolean isDonut() {
      return isDonutCell;
    }

    /** Compares this cell's Manhattan distance to maze's exit 
     * with the passed cell's distance.
     *
     * Returns negative int if this cell's Manhattan distance
     * from exit is closer than other, positive if farther,
     * 0 if distance is equal
     */
    public int compareTo(MazeCell other) {     

      // Retrieve exit information
      SquareCell exit = (SquareCell) this.getExit();
      // Cast other as SquareCell
      SquareCell o = (SquareCell) other;

      // Calculates this cell's Manhattan distance from exit
      // If using BestFS, A* distance if using A* variation
      // (dist_from_entrance is always 0 if using BestFS)
 
      // dist_from_entrance + |cellx-exitx| + |celly - exity|
      int thisDistance = this.getDistance() +
	                 Math.abs(this.row - exit.row) +
                         Math.abs(this.col - exit.col);

      // calculate other cell's A* distance from exit
      int otherDistance = o.getDistance() +
	                  Math.abs(o.row - exit.row) +
                          Math.abs(o.col - exit.col);

      return (thisDistance - otherDistance);
    }

    /**
     * A defined toString function that will output a
     * nicely formated string that specifies the location
     * (row,col) of this cell.
     *
     * @return a string of the form "(row,col)".
     */
    public String toString() {
      return "(" + row + "," + col + ")";
    }

    /**
     * Returns <code>true</code> if there is a wall in the
     * direction <code>d</code>.
     *
     * @param d The direction in which to check for a
     *  wall.
     * @return <code>true</code> if there is a wall in the
     * direction <code>d</code>.
     */
    public boolean isWall(Direction d) {
      return walls[d.toInt()];
    }

    /**
     * Returns the number of walls that this cell has
     *
     * @return the number of walls this cell has
     */
    public int getNumWalls() {
      return numWalls;
    }

    /**
     * Returns the total possible number of walls this cell
     * has.  This can be though of as the number of sides
     * the cell has.
     *
     * @return the maximum number of wall this cell can
     *  have.
     */
    public int getMaxNumWalls() {
      return 4;
    }

    /**
     * Retuns the row this cell is in.
     *
     * @return the row this cell is in.
     */
    public int getRow() {
      return row;
    }

    /**
     * Retuns the column this cell is in.
     *
     * @return the column this cell is in.
     */
    public int getCol() {
      return col;
    }

    /**
     *  An array to keep track of which walls exist on this
     *  cell.
     */
    private boolean[] walls;

    /**
     *  The number of walls this cell has.
     */
    private int numWalls;

    /** Whether or not this cell is a start cell. */
    private boolean isStartCell;

    /** Whether or not this cell is a donut cell. */
    private boolean isDonutCell;

    /** The row this cell is on. */
    private int row;

    /** The column this cell is on. */
    private int col;
  }


    /**
     *  Forms the maze via Kruskal's algorithm.
     */
  /*
  	public SquareCellMaze generateMaze(int width, int height) {
  		int totalCells = height*width;
      int visitedCells = 1;
      
      Random generator = new Random();
      
      int currentRow = generator.nextInt(height);
      int currentCol = generator.nextInt(width);
      
      // current is a random cell in the maze 
      MazeCell current = cells[currentRow][currentCol];
      ArrayStack<MazeCell> stack = new ArrayStack<MazeCell>();

      // while all cells have not been visited
      while (visitedCells < totalCells) {
	      //TODO: viewer.visualize(current);
      	
	      // find neighboring cell with all 4 walls
	      MazeCell next = current.neighborWithWalls();
	      
	      if (next != null) {
          current.knockDownWall(next);
          stack.push(current);
          current = next;
          visitedCells++;
	      }
	      else {
          current = stack.pop();
	      }
      }
  	}  
  	*/	

 
    /**
     * parseMaze takes a file in and tries to generate a
     * SquareCellMaze from that file.
     *
     * @param filename Name of file with data to
     *  generate a SquareCellMaze.
     * @return Returns a new SquareCellMaze based on the
     *  given filename.
     *
     * @exception FileNotFoundException Thrown if the file
     *  cannot be found.
     * @exception IOException Thrown on a generic IO
     *  Exception
     */
  /*static SquareCellMaze parseMaze(String filename)
  throws FileNotFoundException, IOException {
    SquareCellMaze maze = new SquareCellMaze();

    BufferedReader br = new BufferedReader(
                          new FileReader(filename) );
	*/
	public SquareCellMaze parseMaze(InputStream file)
  throws FileNotFoundException, IOException {
    SquareCellMaze maze = new SquareCellMaze();

    BufferedReader br = new BufferedReader(
                          new InputStreamReader(file) );
    String topLine;
    String midLine;
    String bottomLine;

    try {
      String line = br.readLine();
      StringTokenizer st = new StringTokenizer(line);
      maze.width = Integer.parseInt(st.nextToken());
      maze.height = Integer.parseInt(st.nextToken());
      maze.cells = new SquareCell[maze.height][maze.width];

    } catch (NoSuchElementException nsee) {
      System.err.println("Error in Maze: line 1");
      System.err.println(nsee);
      System.exit(1);

    }
    catch (NumberFormatException nfe) {
      System.err.println("Error in Maze: line 1");
      System.err.println(nfe);
      System.exit(1);
    }



    topLine = br.readLine();
    for(int y=0; y < maze.height; y++) {
      midLine = br.readLine();
      bottomLine = br.readLine();

      if( topLine.length() != maze.width*2+1
              || midLine.length() != maze.width*2+1
              || bottomLine.length() != maze.width*2+1 ) {
        System.err.println("Error in Maze"
                           + "near line " + y*2);
        System.exit(1);
      }

      if( topLine.charAt(0) != '+'
              || midLine.charAt(0) != '|'
              || bottomLine.charAt(0) != '+' ) {
        System.err.println("Error in Maze (Corrupt Border) near line "
                           + y*2 + " col 0");
        System.exit(1);
      }

      if( topLine.charAt(maze.width*2) != '+'
              || midLine.charAt(maze.width*2) != '|'
              || bottomLine.charAt(maze.width*2) != '+' ) {
        System.err.println("Error in Maze (Corrupt Border) "
                           +"near line " + y*2 + " col "
                           + topLine.length() );
        System.exit(1);
      }

      for(int x = 0; x < maze.width; x++) {
        boolean isStart = false;
        boolean isDonut = false;
        boolean northWall = false;
        boolean eastWall = false;
        boolean southWall = false;
        boolean westWall = false;

        int mid = x*2+1;
        int right = mid + 1;
        int left = mid - 1;

        if( y == 0 ) {
          if( topLine.charAt(left) != '+'
                  || topLine.charAt(mid) != '-'
                  || topLine.charAt(right) != '+' ) {
            System.err.println("Error in Maze "
                               + "(Corrupt Border) near line "
                               + y*2 + " col " + mid );
            System.exit(1);
          }
        }

        //bug fix, 2/07/06 changed width to height
        if( y == maze.height-1 ) {
          if( bottomLine.charAt(left) != '+'
                  || bottomLine.charAt(mid) != '-'
                  || bottomLine.charAt(right) != '+' ) {
            System.err.println("Error in Maze "
                               +"(Corrupt Border) near line "
                               + y*2 + " col " + mid );
            System.exit(1);
          }
        }

        if(topLine.charAt(mid) == '-') {
          northWall = true;
        }

        if(bottomLine.charAt(mid) == '-') {
          southWall = true;
        }

        if(midLine.charAt(left) == '|') {
          westWall = true;
        }

        if(midLine.charAt(right) == '|') {
          eastWall = true;
        }

        switch(midLine.charAt(mid)) {
        case '*':
          isStart = true;
          break;

        case 'O':
          isDonut = true;
          break;

        case ' ':
          // Do nothing special.
          break;

        default:
          System.err.println("Error in Maze near line "
                             + y*2 + " col " + mid );
          System.exit(1);
        }

        // Create the cell here.
        maze.setCell(y, x, new SquareCell(y, x,
                                          isStart, isDonut,
                                          northWall, eastWall,
                                          southWall, westWall));

        if(isStart) {
          if(maze.startCell != null) {
            System.err.println( "Multiple start cells "
                                + "near line " + y*2 + " col "
                                + topLine.length() );
            System.exit(1);
          }

          maze.startCell = maze.getCell(y,x);
        }

        if(isDonut) {
          if(maze.donutCell != null) {
            System.err.println( "Multiple exit cells "
                                + "near line " + y*2 + " col "
                                + topLine.length() );
            System.exit(1);
          }

          maze.donutCell = maze.getCell(y,x);
        }
      }

      topLine = bottomLine;
    }

    if(maze.startCell == null ) {
      System.err.println("No start cell");
      System.exit(1);
    }

    if(maze.donutCell == null ) {
      System.err.println("No donut cell");
      System.exit(1);
    }

    return maze;
  }
}
