import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;


public class MazeRunnerThread implements Runnable {
	
	SquareCellMaze maze;
	MazeRunner runner;
	
	public MazeRunnerThread(SquareCellMaze maze, MazeRunner runner) {
		this.maze = maze;
		maze.resetCellState();
		this.runner = runner;
	}
	
	public void run() {
		PrintWriter writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)), true);
  	runner.solveMaze(maze, writer);
	}

}
