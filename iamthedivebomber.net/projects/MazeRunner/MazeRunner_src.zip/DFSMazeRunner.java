import java.util.Iterator;
import java.io.PrintWriter;

// This implements the depth-first maze runner using the Stack interface.
// For some more comments, it's a good bet to refer to RandomMazeRunner.java,
// profusely documented by arthur wong.
public class DFSMazeRunner extends MazeRunner {

  // This is a data structure to be inserted as a closure in each cell
  // along the expansion path. Allows retracing of the successful path.
  private static class SolutionPathInfo {
    public MazeCell nextInSolution;
  }

  private int cellsExamined = 0;

  // the main method of this class. documented with in-line comments.
  public void solveMaze(Maze maze, PrintWriter writer) {
  	// tell the maze we're working on it
  	maze.notifyWork();
    // setup: we've examined no cells, get the start cell to begin,
    // and set it to visited. Then we push it onto a stack.
    MazeCell curCell = maze.getStart();
    curCell.setState(MazeCell.CellState.visited);
    Stack<MazeCell> set = new MazeStack<MazeCell>();
    set.push(curCell);

    // now we call the recursive helper method, which will find
    // the donut cell, recording the correct solution path as it
    // returns from it.
    solveMazeHelper(maze, set);

    // We've solved the maze, so now we output the solution.
    writer.println("DFS");
    curCell = maze.getStart();
    int pathLength = 0;

    // Loop through the solution list starting from the first cell
    // and print the path to "writer"
    while(!curCell.isDonut()) {
      pathLength++;
      writer.print(curCell + " ");
      curCell.setState(MazeCell.CellState.solutionPath);
      curCell = getSolutionPathInfo(curCell).nextInSolution;
    }
    // The loop above misses the last cell so just print it.
    writer.println(curCell);

    writer.println("Path length: " + pathLength);
    writer.println("Cells examined: " + cellsExamined);

    // TODO: is the number of cells examined right?
    // notify the maze that we're done working on it
    maze.notifyWork();
  }

  // recursive helper method that pops a cell off the stack, processes it
  // and returns the cell if it led to the donut and null if it didn't
  private MazeCell solveMazeHelper(Maze maze, Stack<MazeCell> set) {
    // first of all, check for empty set
    if (set.isEmpty())
      throw new UnderflowException("The set should never be empty if the algorithm is right.");

    // get a cell and return it right away if it has the donut
    MazeCell curCell = set.top();
    set.pop();
    if (curCell.isDonut())
      return curCell;

    // this cell doesn't have a donut, so let's mark it as a
    // visitInProgress so the listeners can know what's happening.
    curCell.setState(MazeCell.CellState.visitInProgress);

    // add all of its unvisited neighbors to the stack, marking them as
    // visited. we also want to count the neighbors so we don't recur more times
    // than logically makes sense (we could also ensure this by keeping
    // track of our level)
    Iterator neighbors_it = maze.getNeighbors(curCell);
    int neighbors = 0;
    while(neighbors_it.hasNext()) {
      MazeCell neighbor = (MazeCell)neighbors_it.next();
      if (neighbor.getState() == MazeCell.CellState.notVisited) {
        neighbors++;
        neighbor.setState(MazeCell.CellState.visited);
        set.push(neighbor);
      }
    }

    // finally, we count the cell as examined and set its state accordingly,
    // then recur until we either run out of neighbors or get a success
    cellsExamined++;
    curCell.setState(MazeCell.CellState.examined);
    MazeCell returnCell = null;
    while (returnCell == null && neighbors > 0) {
      returnCell = solveMazeHelper(maze, set);
      neighbors--;
    }

    // we came back with something, but did we run out of neighbors or find the donut?
    if (returnCell == null)
      return null; // we hit a dead end

    // if we're here, we've found the donut, so let's get the SolutionPathInfo and
    // link it properly
    getSolutionPathInfo(curCell).nextInSolution = returnCell;
    return curCell;
  }

  // A helper function that returns a pointer to the SolutionPathInfo
  // associated with a given cell. If one does not already exist, the function
  // takes care of creating and associating an instance of SolutionPathInfo.
  private static SolutionPathInfo getSolutionPathInfo(MazeCell curCell) {
    if(null == curCell.getExtraInfo())
      curCell.setExtraInfo( new SolutionPathInfo() );

    return (SolutionPathInfo)curCell.getExtraInfo();
  }
}
