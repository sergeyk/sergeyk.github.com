import java.util.Iterator;
import java.io.PrintWriter;

// This implements the best-first maze runner using the PriorityQueue interface.
public class BestFirstMazeRunner extends MazeRunner {

  // This is a data structure to be inserted as a closure in each cell
  // along the expansion path. Allows retracing of the successful path.
  private static class SolutionPathInfo {
    public MazeCell prevInSolution;
  }

  private int cellsExamined;
  private PriorityQueue<MazeCell> set;
  
  // making sure that the constructor gets the right params is the
  // Launcher's job
  public BestFirstMazeRunner(String s) {
    this(s, 0);
  }
  public BestFirstMazeRunner(String s, int d) {
    cellsExamined = 0;
    if (s.equals("bin"))
      set = new BinaryHeap<MazeCell>();
    else if (s.equals("three"))
      set = new ThreeHeap<MazeCell>();
    else if (s.equals("dheap"))
      set = new DHeap<MazeCell>(d);
    else if (s.equals("ptr"))
      set = new BinomialQueue<MazeCell>();
    else
      throw new IllegalArgumentException("What type of data structure should BestFirst use then?");
  }  

  public void solveMaze(Maze maze, PrintWriter writer) {
  	// tell the maze we're working on it
  	maze.notifyWork();
  	
    // go through all the cells in the maze, letting them know
    // where the donut cell is. This will let the compareTo method
    // work.
    MazeCell donutCell = maze.getDonut();
    Iterator it = maze.getCells();
    while(it.hasNext()) {
      MazeCell cell = (MazeCell)it.next();
      cell.setExit(donutCell);
    }

    // setup: we've examined no cells, get the start cell to begin,
    // and set it to visited. Then we push it onto a stack.
    MazeCell curCell = maze.getStart();
    curCell.setState(MazeCell.CellState.visited);
    set.insert(curCell);

    // now we call the recursive helper method that's going to return
    // the donut cell. The SolutionPathInfo of that cell, and of every
    // cell on the path, will link to the previous cell on the path.
    donutCell = solveMazeHelper(maze, set);

    // We've solved the maze, so now we output the solution.
    writer.println("Best First");
    curCell = donutCell;
    MazeCell startCell = maze.getStart();
    int pathLength = 0;
    Stack<MazeCell> solutionStack = new MazeStack<MazeCell>();

    // Loop through the solution list starting from the donut cell backwards.
    // Push the cells onto a stack as you go.
    while (curCell != startCell) {
      pathLength++;
      solutionStack.push(curCell);
      curCell = getSolutionPathInfo(curCell).prevInSolution;
    }
    // push the last cell on
    solutionStack.push(curCell);

    // Loop again to print and display the solution path in proper order.
    while (!solutionStack.isEmpty()) {
      curCell = solutionStack.top();
      solutionStack.pop();
      curCell.setState(MazeCell.CellState.solutionPath);
      writer.print(curCell + " ");
    }

    writer.println();
    writer.println("Path length: " + pathLength);
    writer.println("Cells examined: " + cellsExamined);
    
    // notify the maze that we're done working on it
    maze.notifyWork();
  }

  // recursive helper method that dequeues from the set, enqueues
  // all neighbors, and then recurs until it gets a success or runs out of
  // the neighbors it enqueued.
  private MazeCell solveMazeHelper(Maze maze, PriorityQueue<MazeCell> set) {
    // first of all, check for empty set
    if (set.isEmpty())
      throw new UnderflowException("The set should never be empty if the algorithm is right.");

    // get a cell and return it right away if it has the donut
    MazeCell curCell = set.deleteMin();
    if (curCell.isDonut())
      return curCell;

    // this cell doesn't have a donut, so let's mark it as a
    // visitInProgress so the listeners can know what's happening.
    curCell.setState(MazeCell.CellState.visitInProgress);

    // now add all of this cell's unvisited neighbors to the queue,
    // making this cell prevInSolution for them and marking them as visited.
    Iterator neighbors_it = maze.getNeighbors(curCell);
    while(neighbors_it.hasNext()) {
      MazeCell neighbor = (MazeCell)neighbors_it.next();
      if (neighbor.getState() == MazeCell.CellState.notVisited) {
        neighbor.setState(MazeCell.CellState.visited);
        getSolutionPathInfo(neighbor).prevInSolution = curCell;
        set.insert(neighbor);
      }
    }

    // finally, we count current cell as examined and set its state accordingly,
    // then recur until we get a success
    cellsExamined++;
    curCell.setState(MazeCell.CellState.examined);
    MazeCell returnCell = null;
    while (returnCell == null)
      returnCell = solveMazeHelper(maze, set);

    return returnCell;
  }

  // A helper function that returns a pointer to the SolutionPathInfo
  // associated with a given cell. If one does not already exist, the function
  // takes care of creating and associating an instance of SolutionPathInfo.
  private static SolutionPathInfo getSolutionPathInfo(MazeCell curCell) {
    if(null == curCell.getExtraInfo())
      curCell.setExtraInfo( new SolutionPathInfo() );
    return (SolutionPathInfo)curCell.getExtraInfo();
  }
}
