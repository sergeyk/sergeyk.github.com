/* Sergey Karayev and Victoria Kirst
 * CSE 326 -- Summer 2007
 * Project 2A
 * MazeQueue is an "any type" queue that implements the Queue<E> interface.
 */

public class MazeQueue<E> implements Queue<E> {

  // Self-referencing Node class for linked list
  private class Node<E> {
    public Node (E value) {
      data = value;
      next = null;
    }
    // reference to next node in list
    public Node<E> next;
    // stored data in node
    public E data;
  }

  // Reference to front of queue
  private Node<E> front;
  // Reference to back of queue
  private Node<E> back;

  public MazeQueue() {
    front = null;
    back = null;
  }

  /**
   * Returns true if queue has no elements
   *
   * @return  true if the  queue has no elements
   */
  public boolean isEmpty() {
    return front == null;
  }

  /**
   * Enqueues a new object to the queue
   *
   * @param x Object to be enqueued into the queue.
   */
  public void enqueue(E x) {
    if (isEmpty())
      front = back = new Node<E>(x);
    else {
      back.next = new Node<E>(x);
      back = back.next;
    }
  }

  /**
   * Get the least recently inserted item in the queue.
   * Does not alter the queue.
   *
   * @return  The front of the queue.
   * @exception UnderflowException Thrown if queue is empty.
   */
  public E peek() {
    if (isEmpty())
      throw new UnderflowException("Cannot Peek at Empty List");
    return front.data;
  }

  /**
   * dequeues the front of the queue.
   *
   * @return  The front of the queue.
   * @exception UnderflowException Thrown if queue is empty.
   */
  public E dequeue() {
    if (isEmpty())
      throw new UnderflowException("Cannot Dequeue Empty List");
    E returnData = front.data;
    front = front.next;
    return returnData;
  }

  /**
   * Erases all elements from the queue.
   */
  public void makeEmpty() {
    front = null;
    back = null;
  }
}